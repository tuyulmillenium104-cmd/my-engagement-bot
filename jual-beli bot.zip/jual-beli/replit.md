# Replit.md

## Overview

This is a Discord bot application built with Python using the discord.py library. The bot appears to be designed for community engagement and gamification, featuring a virtual currency/points system with daily rewards, engagement tracking (likes, comments, retweets, follows), and role-based tier systems for users based on their accumulated points.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Bot Framework
- **Framework**: discord.py with commands extension
- **Command Prefix**: `!` (exclamation mark)
- **Intents**: Message content, reactions, and members enabled for full interaction capabilities

### State Management
- **In-Memory State**: Uses Python `defaultdict` for tracking:
  - User message counts (with timestamps as lists)
  - User mute levels (integer tracking)
  - Daily reward tracking (count and reset timestamps)
  - Last daily reward timestamps

### Data Persistence
- **Storage**: JSON file-based persistence
- **Concurrency**: Async file lock (`asyncio.Lock`) to prevent race conditions during file operations
- **Pattern**: Load/save functions with error handling and default value fallbacks

### Gamification System
- **Engagement Pricing**: Point values for different engagement types:
  - Like: 0.5 points
  - Comment: 1.0 points
  - Retweet: 1.5 points
  - Follow: 2.0 points

- **Role Tiers**: Users are categorized by point thresholds:
  - 100+ points: "Whale"
  - 50+ points: "Sultan"
  - 10+ points: "Ekonomi Menengah"
  - 0.1+ points: "Butuh Donasi"

### Keep-Alive Mechanism
- Placeholder module exists for web server keep-alive functionality (common pattern for hosting Discord bots on platforms like Replit)

## External Dependencies

### Python Packages
- **discord.py**: Core Discord API wrapper for bot functionality
- **Standard Library**: os, json, collections, asyncio, re

### Environment Variables
- **DISCORD_TOKEN** (expected): Bot authentication token should be stored as a secret

### External Services
- **Discord API**: Primary integration for bot operations
- No database service currently configured (uses local JSON files)